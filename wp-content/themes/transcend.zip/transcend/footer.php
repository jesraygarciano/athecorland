</div>
<!--START OF FOOTER-->
<footer>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img class="footer-logo" src="<?php bloginfo("template_directory");?>/img/athecor_logo.png" alt="">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quid turpius quam sapientis vitam ex insipientium sermone pendere? Istam voluptatem perpetuam quis potest praestare sapienti? Qui non moveatur et offensione turpitudinis et comprobatione honestatis?</p>
            </div>

            <div class="col-md-3">
                <h3>Contact Info</h3>
                <p>A.C Cortes Avenue, Mandaue City (next to RCBC Bank, across KIA Motors) Cebu, Philippines, 6014</p>
                <p>TEL : <br> +6332 344-3119<br> +6332 344-3119</p>
            </div>

            <div class="col-md-3">
                <h3>Projects</h3>
                <ul>
                    <li><a href="#">88 Hillside</a></li>
                    <li><a href="#">88 Summer Breeze</a></li>
                    <li><a href="#">88 Brookside</a></li>
                    <li><a href="#">88 South Covina</a></li>
                </ul>
            </div>
        </div>
    </div>

</footer>

</body>
<?php wp_footer();?>
</html>