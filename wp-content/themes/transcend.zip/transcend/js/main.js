/**
 * Created by waynegeek on 4/14/2017.
 */

$(document).ready(function(){
    $("#btn-emailus").click(function(){
        window.location.href = "http://192.168.254.103/athecor/contact-us";
    });
});