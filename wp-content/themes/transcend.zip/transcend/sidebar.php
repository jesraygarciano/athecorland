<div class="col-md-4" id="sidebar-cont">
    <div class="sidebar-fixed">
    <h2>Newsletter</h2>
    <p>Subscribe to Athecor newsletter and get updates on project launches.Exclusive promos and discounts and Athecor updates.</p>
    <form>
        <label class="custom-file">
            <input type="text" id="newsletter" placeholder="Enter email address">
            <span class="fa fa-envelope"></span>
        </label>
    </form>
    <h2 class="follow-us">Follow us</h2>
    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fweb.facebook.com%2FAthecorLand%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
    </div>
</div>